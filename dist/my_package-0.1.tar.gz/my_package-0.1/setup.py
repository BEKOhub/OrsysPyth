from setuptools import setup, find_packages

setup(
    name="my_package",
    version="0.1",
    author="HamzaBEK",
    author_email="hamza.bekoury@hotmail.com",
    description="Un package exemple",
    packages=find_packages(),
    install_requires=[],
)
