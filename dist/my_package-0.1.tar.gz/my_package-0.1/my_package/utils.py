def Hello(nom):
    return f"Hello, {nom} !"
